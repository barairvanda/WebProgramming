<?php
class Perkenalan extends CI_Controller
{
	
	public function index()
	{
		echo "<h1>Perkenalan</h1>";
		echo "Nama Saya Maulana Yusuf
			Saya tinggal di Tegal";
	}
}